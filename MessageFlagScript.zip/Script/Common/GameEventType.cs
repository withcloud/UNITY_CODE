﻿public enum GameEventType
{

    GetCurrentQueIndex,
    GetGameProgress,

}
